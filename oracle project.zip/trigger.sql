set serveroutput on;
/
--�α� Ʈ����--
create or replace trigger tri_log
after insert or delete on login
for each row

begin    
  if inserting then
    insert into t_log
    values(:new.id, 'login', sysdate);
  elsif deleting then
    insert into t_log
    values(:old.id, 'logout', sysdate);
  end if;
end;  
/

--���� Ʈ����--
create or replace trigger tri_off
after insert on offwork
for each row
begin  
  delete from charge;
  delete from c_order;
  delete from t_query;
  
  dbms_output.put_line('���� �Ϸ� �����ϼ̽��ϴ�');
end;
/
